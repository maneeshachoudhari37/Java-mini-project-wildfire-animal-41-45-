package wildlife.model;

import java.time.LocalDateTime;

public class Alert {
    private final String message;
    private final LocalDateTime time;
    private Ranger assignedRanger;

    public Alert(String message) {
        this.message = message;
        this.time = LocalDateTime.now();
    }

    public String getMessage() { return message; }
    public LocalDateTime getTime() { return time; }
    public Ranger getAssignedRanger() { return assignedRanger; }
    public void assignRanger(Ranger ranger) { this.assignedRanger = ranger; }

    @Override
    public String toString() {
        return time + " | " + message + " | Ranger: "
            + (assignedRanger == null ? "Not assigned" : assignedRanger.getName());
    }
}
