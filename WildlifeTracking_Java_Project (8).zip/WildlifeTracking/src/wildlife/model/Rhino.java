package wildlife.model;

public class Rhino extends Animal {
    public Rhino(String id, String name, Location location, Zone safeZone) {
        super(id, name, location, safeZone);
    }

    @Override
    public String getSpecies() { return "Rhino"; }
}
