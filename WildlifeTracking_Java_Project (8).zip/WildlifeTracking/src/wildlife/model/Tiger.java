package wildlife.model;

public class Tiger extends Animal {
    public Tiger(String id, String name, Location location, Zone safeZone) {
        super(id, name, location, safeZone);
    }

    @Override
    public String getSpecies() { return "Tiger"; }
}
