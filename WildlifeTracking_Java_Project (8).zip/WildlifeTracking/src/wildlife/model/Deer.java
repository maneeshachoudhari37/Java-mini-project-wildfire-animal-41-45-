package wildlife.model;

public class Deer extends Animal {
    public Deer(String id, String name, Location location, Zone safeZone) {
        super(id, name, location, safeZone);
    }

    @Override
    public String getSpecies() { return "Deer"; }
}
