package wildlife.model;

public class Zone {
    private final String name;
    private final double minX, maxX, minY, maxY;

    public Zone(String name, double minX, double maxX, double minY, double maxY) {
        if (minX > maxX || minY > maxY) {
            throw new IllegalArgumentException("Invalid zone boundaries");
        }
        this.name = name;
        this.minX = minX;
        this.maxX = maxX;
        this.minY = minY;
        this.maxY = maxY;
    }

    public String getName() { return name; }

    public boolean contains(Location location) {
        return location.getX() >= minX && location.getX() <= maxX
            && location.getY() >= minY && location.getY() <= maxY;
    }

    @Override
    public String toString() {
        return name + " [x: " + minX + " to " + maxX + ", y: " + minY + " to " + maxY + "]";
    }
}
