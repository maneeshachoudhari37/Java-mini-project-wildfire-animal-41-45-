package wildlife.model;

public class Elephant extends Animal {
    public Elephant(String id, String name, Location location, Zone safeZone) {
        super(id, name, location, safeZone);
    }

    @Override
    public String getSpecies() { return "Elephant"; }
}
