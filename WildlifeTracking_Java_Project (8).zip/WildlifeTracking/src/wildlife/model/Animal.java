package wildlife.model;

public abstract class Animal {
    private final String id;
    private final String name;
    private final Zone safeZone;
    private Location location;

    protected Animal(String id, String name, Location location, Zone safeZone) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.safeZone = safeZone;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public Location getLocation() { return location; }
    public Zone getSafeZone() { return safeZone; }
    public void setLocation(Location location) { this.location = location; }
    public abstract String getSpecies();

    @Override
    public String toString() {
        return getSpecies() + " " + name + " [ID=" + id + "] at " + location;
    }
}
