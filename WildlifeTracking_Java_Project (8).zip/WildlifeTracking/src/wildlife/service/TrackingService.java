package wildlife.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import wildlife.exception.ZoneBreachException;
import wildlife.model.Alert;
import wildlife.model.Animal;
import wildlife.model.Location;
import wildlife.model.Ranger;
import wildlife.model.Zone;

public class TrackingService implements Runnable {
    private final List<Animal> animals;
    private final List<Alert> alerts;
    private final List<Ranger> rangers;
    private final Random random = new Random();
    private volatile boolean running = true;

    public TrackingService(List<Animal> animals, List<Ranger> rangers) {
        this.animals = animals;
        this.rangers = rangers;
        this.alerts = new ArrayList<>();
    }

    @Override
    public void run() {
        while (running) {
            updateAnimalPositions();
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    private void updateAnimalPositions() {
        synchronized (animals) {
            for (Animal animal : animals) {
                Location current = animal.getLocation();
                // Small random movement in each tracking cycle.
                current.move(random.nextDouble() * 4.0 - 2.0,
                             random.nextDouble() * 4.0 - 2.0);
                System.out.println("Updated: " + animal);
                try {
                    checkZone(animal);
                } catch (ZoneBreachException e) {
                    createAlert(e.getMessage());
                }
            }
        }

        // Simulation of an unknown-person entry event (not real sensor detection).
        if (random.nextInt(10) == 0) {
            createAlert("SECURITY ALERT: Unknown person detected entering the sanctuary zone.");
        }
    }

    private void checkZone(Animal animal) throws ZoneBreachException {
        Zone zone = animal.getSafeZone();
        if (!zone.contains(animal.getLocation())) {
            throw new ZoneBreachException("ZONE BREACH: " + animal.getSpecies()
                + " " + animal.getName() + " (ID=" + animal.getId() + ") left "
                + zone.getName() + ". Current location: " + animal.getLocation());
        }
    }

    private synchronized void createAlert(String message) {
        Alert alert = new Alert(message);
        if (!rangers.isEmpty()) {
            // Assign alerts to rangers in round-robin order.
            alert.assignRanger(rangers.get(alerts.size() % rangers.size()));
        }
        alerts.add(alert);
        System.out.println("\n*** " + alert + " ***\n");
    }

    public void stopTracking() { running = false; }
    public List<Alert> getAlerts() { return alerts; }
}
