package wildlife.exception;

public class ZoneBreachException extends Exception {
    public ZoneBreachException(String message) {
        super(message);
    }
}
