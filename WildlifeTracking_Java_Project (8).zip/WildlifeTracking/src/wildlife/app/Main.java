package wildlife.app;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import wildlife.model.Animal;
import wildlife.model.Deer;
import wildlife.model.Elephant;
import wildlife.model.Location;
import wildlife.model.Ranger;
import wildlife.model.Rhino;
import wildlife.model.Tiger;
import wildlife.model.Zone;
import wildlife.service.TrackingService;
import wildlife.util.FileManager;

public class Main {
    public static void main(String[] args) {
        List<Animal> animals = new ArrayList<>();
        List<Ranger> rangers = new ArrayList<>();

        Zone centralZone = new Zone("Central Safe Zone", 0, 100, 0, 100);
        Zone forestZone = new Zone("Forest Safe Zone", 0, 100, 0, 100);

        // Sample animal registrations. All start inside their assigned safe zone.
        animals.add(new Tiger("A101", "Sher", new Location(50, 50), centralZone));
        animals.add(new Elephant("A102", "Gaj", new Location(30, 40), centralZone));
        animals.add(new Deer("A103", "Chital", new Location(70, 60), forestZone));
        animals.add(new Rhino("A104", "Raju", new Location(20, 25), forestZone));

        rangers.add(new Ranger("R01", "Ranger Arun"));
        rangers.add(new Ranger("R02", "Ranger Meena"));

        TrackingService trackingService = new TrackingService(animals, rangers);
        Thread trackingThread = new Thread(trackingService, "Animal-Tracking-Thread");
        trackingThread.start();

        System.out.println("\nWildlife Tracking System started.");
        System.out.println("Tracking runs every 1.5 seconds.");
        System.out.println("Press ENTER to stop tracking and generate the report.\n");

        try (Scanner scanner = new Scanner(System.in)) {
            scanner.nextLine();
        }

        trackingService.stopTracking();
        trackingThread.interrupt();
        try {
            trackingThread.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Main thread was interrupted while stopping tracking.");
        }

        System.out.println("\n========== FINAL ANIMAL COUNT ==========");
        System.out.println("Total registered animals: " + animals.size());
        for (Animal animal : animals) {
            System.out.println(animal + " | Safe zone: " + animal.getSafeZone().getName());
        }

        System.out.println("\n========== ALERT SUMMARY ==========");
        List<wildlife.model.Alert> alerts = trackingService.getAlerts();
        if (alerts.isEmpty()) {
            System.out.println("No alerts were generated.");
        } else {
            for (wildlife.model.Alert alert : alerts) {
                System.out.println(alert);
            }
        }

        FileManager.saveReport(animals, alerts);
        System.out.println("Wildlife Tracking System stopped.");
    }
}
