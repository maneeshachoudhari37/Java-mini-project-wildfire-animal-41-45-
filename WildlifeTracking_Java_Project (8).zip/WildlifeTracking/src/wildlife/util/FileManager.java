package wildlife.util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import wildlife.model.Alert;
import wildlife.model.Animal;

public class FileManager {
    private static final String FILE_NAME = "wildlife_report.txt";

    public static void saveReport(List<Animal> animals, List<Alert> alerts) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            writer.write("WILDLIFE SANCTUARY DAILY REPORT");
            writer.newLine();
            writer.write("Total animals: " + animals.size());
            writer.newLine();
            writer.write("Animal details:");
            writer.newLine();
            for (Animal animal : animals) {
                writer.write(animal.toString() + " | Zone: " + animal.getSafeZone().getName());
                writer.newLine();
            }
            writer.newLine();
            writer.write("Total alerts: " + alerts.size());
            writer.newLine();
            for (Alert alert : alerts) {
                writer.write(alert.toString());
                writer.newLine();
            }
            System.out.println("Report saved to " + FILE_NAME);
        } catch (IOException e) {
            System.out.println("Could not save report: " + e.getMessage());
        }
    }
}
